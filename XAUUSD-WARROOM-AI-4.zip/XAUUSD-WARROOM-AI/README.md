# XAU/USD WAR ROOM AI v22.0

## Cara menjalankan
1. `npm install`
2. Copy `.env.example` jadi `.env`, isi `GOLD_API_KEY` dengan API key dari Twelve Data (atau provider lain yang kompatibel).
3. `node server.js`
4. Buka `http://localhost:3000`

## Struktur
```
XAUUSD-WARROOM-AI/
├── package.json
├── config.js
├── server.js          ← semua engine terhubung di sini (/api/ai-analysis)
├── telegram.js
├── index.html
├── style.css
├── app.js
├── manifest.json
├── .env.example
└── engines/
    ├── technical-engine.js
    ├── smart-money.js
    ├── fibonacci.js
    ├── multi-timeframe.js
    ├── sniper-entry.js
    ├── risk-engine.js
    ├── news-engine.js
    ├── session-engine.js
    ├── candle-engine.js
    ├── confidence-engine.js
    └── journal-engine.js
```

## Catatan
- Endpoint utama: `GET /api/ai-analysis` — menggabungkan technical, smart money, fibonacci, candle pattern, session, news filter, confidence score, dan trade plan (BUY LIMIT/SELL LIMIT) dalam satu response JSON.
- Sinyal baru otomatis tersimpan ke `journal.json` dan (opsional) dikirim ke Telegram jika `TELEGRAM_BOT_TOKEN` & `TELEGRAM_CHAT_ID` diisi di `.env`.
- Dashboard polling tiap 10 detik untuk menghemat kuota API.
- Alat ini untuk bantu analisis, bukan jaminan profit — selalu uji di akun demo dulu.
