// ==========================================
// XAU/USD WAR ROOM AI v22.0
// FRONTEND COMMANDER
// ==========================================

const API = window.location.origin; // otomatis ikut host server, tak perlu hardcode localhost

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = value;
}

async function loadAI() {
  try {
    const response = await fetch(API + "/api/ai-analysis");
    const data = await response.json();

    if (data.error) {
      setText("decision", "⚠ " + data.message);
      return;
    }

    // PRICE
    setText("price", data.price.toFixed(2));

    // SESSION
    setText("session", data.session.session);

    // CONFIDENCE
    setText("confidenceGrade", data.confidence.grade);
    setText("confidenceScore", data.confidence.score + "/100");

    // TECHNICAL
    setText("ema20", data.technical.ema20 ? data.technical.ema20.toFixed(2) : "--");
    setText("ema50", data.technical.ema50 ? data.technical.ema50.toFixed(2) : "--");
    setText("ema200", data.technical.ema200 ? data.technical.ema200.toFixed(2) : "--");
    setText("rsi", data.technical.rsi ? data.technical.rsi.toFixed(2) : "--");
    if (data.technical.macd) setText("macd", data.technical.macd.histogram.toFixed(3));
    setText("atr", data.technical.atr ? data.technical.atr.toFixed(2) : "--");

    // SMART MONEY
    setText("structure", data.smartMoney.structure);
    setText("liquidity", data.smartMoney.liquidity || "--");
    setText("institution", data.smartMoney.bias);

    // CANDLE + FIBONACCI + NEWS
    setText("candlePattern", data.candle.pattern);
    setText("fibZone", data.fibonacci.zone);
    setText("newsWarning", data.news.warning);

    // DECISION
    if (data.trade.type === "BUY LIMIT") {
      setText("decision", "🟢 BUY LIMIT");
    } else if (data.trade.type === "SELL LIMIT") {
      setText("decision", "🔴 SELL LIMIT");
    } else {
      setText("decision", "WAIT CONFIRMATION");
    }

    // TRADE PLAN (reset dulu supaya tidak nyangkut nilai lama)
    setText("buyEntry", "--"); setText("buySL", "--"); setText("buyTP", "--");
    setText("sellEntry", "--"); setText("sellSL", "--"); setText("sellTP", "--");

    if (data.trade.type === "BUY LIMIT") {
      setText("buyEntry", data.trade.entry);
      setText("buySL", data.trade.sl);
      setText("buyTP", data.trade.tp1);
    }

    if (data.trade.type === "SELL LIMIT") {
      setText("sellEntry", data.trade.entry);
      setText("sellSL", data.trade.sl);
      setText("sellTP", data.trade.tp1);
    }

    // PROBABILITY (perkiraan sederhana dari skor gabungan)
    const score = data.technical.score + data.smartMoney.score;
    const buy = Math.max(0, Math.min(100, 50 + score));
    const sell = 100 - buy;

    setText("buyProb", buy.toFixed(0) + "%");
    setText("sellProb", sell.toFixed(0) + "%");

  } catch (error) {
    console.log(error);
    setText("decision", "⚠ Gagal konek ke server");
  }
}

// UPDATE TIAP 10 DETIK (hemat kuota API)
setInterval(loadAI, 10000);
loadAI();

// ==========================================
// TRADINGVIEW CHART
// ==========================================
if (typeof TradingView !== "undefined") {
  new TradingView.widget({
    container_id: "tv_chart",
    width: "100%",
    height: 600,
    symbol: "OANDA:XAUUSD",
    interval: "5",
    timezone: "Asia/Jakarta",
    theme: "dark",
    style: "1",
    locale: "id",
    toolbar_bg: "#111111",
    enable_publishing: false
  });
}

// ==========================================
// RISK CALCULATOR (lokal, tanpa perlu server)
// ==========================================
function calculateRisk() {
  const balance = Number(document.getElementById("balance").value) || 0;
  const risk = Number(document.getElementById("risk").value) || 0;
  const money = balance * (risk / 100);

  setText("lot", "Risk Money: $" + money.toFixed(2));
}
