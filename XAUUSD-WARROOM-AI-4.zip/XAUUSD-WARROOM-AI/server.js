// ==========================================
// XAU/USD GLOBAL INSTITUTIONAL WAR ROOM AI
// BACKEND SERVER v22.0 - FINAL INTEGRATED
// ==========================================

const express = require("express");
const axios = require("axios");
const cors = require("cors");
const CONFIG = require("./config");

const technicalAnalysis = require("./engines/technical-engine");
const smartMoneyAnalysis = require("./engines/smart-money");
const fibonacciAnalysis = require("./engines/fibonacci");
const sniperEntry = require("./engines/sniper-entry");
const calculateRisk = require("./engines/risk-engine");
const sessionAnalysis = require("./engines/session-engine");
const analyzeNews = require("./engines/news-engine");
const candleAnalysis = require("./engines/candle-engine");
const confidenceScore = require("./engines/confidence-engine");
const saveSignal = require("./engines/journal-engine");
const sendTelegram = require("./telegram");

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(".")); // menyajikan index.html, style.css, app.js

// Simpan sinyal terakhir agar tidak spam telegram/journal tiap 5-10 detik
let lastAlertType = null;

// ==========================================
// LIVE GOLD PRICE
// ==========================================
app.get("/api/price", async (req, res) => {
  try {
    const data = await axios.get(
      `https://api.twelvedata.com/price?symbol=${CONFIG.SYMBOL}&apikey=${CONFIG.API_KEY}`
    );

    res.json({
      symbol: CONFIG.SYMBOL,
      price: Number(data.data.price),
      time: new Date()
    });
  } catch (error) {
    res.status(500).json({ error: true, message: "Price API gagal" });
  }
});

// ==========================================
// LIVE CANDLE DATA
// ==========================================
app.get("/api/candles", async (req, res) => {
  try {
    const data = await axios.get(
      `https://api.twelvedata.com/time_series?symbol=${CONFIG.SYMBOL}&interval=${CONFIG.DEFAULT_TIMEFRAME}&outputsize=200&apikey=${CONFIG.API_KEY}`
    );

    res.json(data.data.values);
  } catch (error) {
    res.status(500).json({ error: true, message: "Candle API gagal" });
  }
});

// ==========================================
// RAW TECHNICAL ENGINE (opsional, debug)
// ==========================================
app.get("/api/technical", async (req, res) => {
  try {
    const response = await axios.get(
      `https://api.twelvedata.com/time_series?symbol=${CONFIG.SYMBOL}&interval=5min&outputsize=200&apikey=${CONFIG.API_KEY}`
    );

    const candles = response.data.values.reverse();
    const formatted = candles.map(x => ({
      open: Number(x.open),
      high: Number(x.high),
      low: Number(x.low),
      close: Number(x.close)
    }));

    res.json(technicalAnalysis(formatted));
  } catch (error) {
    res.status(500).json({ error: true, message: error.message });
  }
});

// ==========================================
// AI COMMANDER - FINAL ENGINE
// Menggabungkan semua engine jadi satu sinyal
// ==========================================
app.get("/api/ai-analysis", async (req, res) => {
  try {
    const response = await axios.get(
      `https://api.twelvedata.com/time_series?symbol=${CONFIG.SYMBOL}&interval=5min&outputsize=200&apikey=${CONFIG.API_KEY}`
    );

    if (!response.data || !response.data.values) {
      throw new Error(response.data && response.data.message ? response.data.message : "Data candle kosong / API key tidak valid");
    }

    const candles = response.data.values.reverse();
    const formatted = candles.map(x => ({
      open: Number(x.open),
      high: Number(x.high),
      low: Number(x.low),
      close: Number(x.close)
    }));

    // TECHNICAL
    const technical = technicalAnalysis(formatted);

    // SMART MONEY
    const smartMoney = smartMoneyAnalysis(formatted);

    // FIBONACCI
    const fibonacci = fibonacciAnalysis(formatted);

    // CANDLE PATTERN
    const candle = candleAnalysis(formatted);

    // SESSION (jam WIB)
    const hour = new Date().getHours();
    const session = sessionAnalysis(hour);

    // NEWS (placeholder - bisa dihubungkan ke calendar API nanti)
    const news = analyzeNews([]);

    // FINAL BIAS
    let bias;
    if (technical.signal === "BUY" && smartMoney.bias === "INSTITUTIONAL BUY") {
      bias = "BULLISH";
    } else if (technical.signal === "SELL" && smartMoney.bias === "INSTITUTIONAL SELL") {
      bias = "BEARISH";
    } else {
      bias = "WAIT";
    }

    // ENTRY / TRADE PLAN
    const trade = sniperEntry(technical.price, smartMoney, fibonacci, bias);

    // CONFIDENCE
    const confidence = confidenceScore({
      technical,
      smart: smartMoney,
      candle,
      news: news.impact
    });

    const result = {
      price: technical.price,
      technical,
      smartMoney,
      fibonacci,
      candle,
      session,
      news,
      confidence,
      trade
    };

    // Simpan ke journal & kirim telegram hanya saat ada setup baru (bukan tiap polling)
    if (trade.type !== "NO TRADE" && trade.type !== lastAlertType) {
      lastAlertType = trade.type;
      saveSignal({ trade, confidence, price: technical.price });
      sendTelegram(
        `${trade.type} XAUUSD\nEntry: ${trade.entry}\nSL: ${trade.sl}\nTP1: ${trade.tp1}\nConfidence: ${confidence.score} (${confidence.grade})`
      );
    } else if (trade.type === "NO TRADE") {
      lastAlertType = null;
    }

    res.json(result);
  } catch (error) {
    res.status(500).json({ error: true, message: error.message });
  }
});

// ==========================================
// RISK CALCULATOR API (opsional, dipakai app.js lokal juga bisa)
// ==========================================
app.post("/api/risk", (req, res) => {
  try {
    const { balance, riskPercent, entry, stopLoss, takeProfit } = req.body;
    res.json(calculateRisk(balance, riskPercent, entry, stopLoss, takeProfit));
  } catch (error) {
    res.status(500).json({ error: true, message: error.message });
  }
});

// ==========================================
// SERVER START
// ==========================================
app.listen(CONFIG.SERVER_PORT, () => {
  console.log(`
================================
XAU/USD WAR ROOM AI v22.0
SERVER RUNNING
PORT: ${CONFIG.SERVER_PORT}
================================
`);

  if (CONFIG.API_KEY === "MASUKKAN_API_KEY_ANDA") {
    console.log("⚠ PERINGATAN: API_KEY belum diisi. Edit file .env (GOLD_API_KEY=...) sebelum dipakai live.");
  }
});
