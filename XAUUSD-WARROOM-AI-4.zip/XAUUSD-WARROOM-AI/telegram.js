// ======================================
// TELEGRAM ALERT FRAMEWORK
// ======================================

const axios = require("axios");
const CONFIG = require("./config");

async function sendTelegram(message) {
  if (!CONFIG.TELEGRAM_BOT_TOKEN || !CONFIG.TELEGRAM_CHAT_ID) {
    // Belum dikonfigurasi, lewati saja tanpa error
    return;
  }

  try {
    await axios.post(
      `https://api.telegram.org/bot${CONFIG.TELEGRAM_BOT_TOKEN}/sendMessage`,
      {
        chat_id: CONFIG.TELEGRAM_CHAT_ID,
        text: message
      }
    );
  } catch (error) {
    console.log("Telegram gagal kirim:", error.message);
  }
}

module.exports = sendTelegram;
