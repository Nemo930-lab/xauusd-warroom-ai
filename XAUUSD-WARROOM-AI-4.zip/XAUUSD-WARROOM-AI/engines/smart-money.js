// ======================================
// XAU/USD WAR ROOM AI v22.0
// SMART MONEY CONCEPT ENGINE
// BOS CHOCH FVG ORDER BLOCK LIQUIDITY
// ======================================

function smartMoneyAnalysis(candles) {
  const result = {
    structure: "",
    trend: "",
    liquidity: "",
    orderBlock: "",
    fvg: "",
    score: 0
  };

  const last = candles[candles.length - 1];
  const previous = candles[candles.length - 2];
  const before = candles[candles.length - 3];

  // BREAK OF STRUCTURE (BOS)
  if (last.close > previous.high) {
    result.structure = "BULLISH BOS";
    result.trend = "BULLISH";
    result.score += 20;
  } else if (last.close < previous.low) {
    result.structure = "BEARISH BOS";
    result.trend = "BEARISH";
    result.score -= 20;
  } else {
    result.structure = "RANGE";
  }

  // LIQUIDITY SWEEP
  if (last.high > previous.high && last.close < previous.high) {
    result.liquidity = "BUY SIDE LIQUIDITY TAKEN";
    result.score -= 5;
  }
  if (last.low < previous.low && last.close > previous.low) {
    result.liquidity = "SELL SIDE LIQUIDITY TAKEN";
    result.score += 10;
  }

  // ORDER BLOCK DETECTION
  if (before.close < before.open && last.close > before.high) {
    result.orderBlock = "BULLISH ORDER BLOCK";
    result.score += 15;
  }
  if (before.close > before.open && last.close < before.low) {
    result.orderBlock = "BEARISH ORDER BLOCK";
    result.score -= 15;
  }

  // FAIR VALUE GAP
  const candle1 = candles[candles.length - 3];
  const candle3 = candles[candles.length - 1];
  if (candle1.high < candle3.low) {
    result.fvg = "BULLISH FVG";
    result.score += 10;
  } else if (candle1.low > candle3.high) {
    result.fvg = "BEARISH FVG";
    result.score -= 10;
  } else {
    result.fvg = "NO FVG";
  }

  // FINAL SMART MONEY BIAS
  if (result.score >= 25) result.bias = "INSTITUTIONAL BUY";
  else if (result.score <= -25) result.bias = "INSTITUTIONAL SELL";
  else result.bias = "NEUTRAL";

  return result;
}

module.exports = smartMoneyAnalysis;
