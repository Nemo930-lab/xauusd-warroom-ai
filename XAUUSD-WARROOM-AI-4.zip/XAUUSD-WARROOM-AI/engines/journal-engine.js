// ======================================
// JOURNAL ENGINE - simpan riwayat sinyal
// ======================================

const fs = require("fs");
const path = require("path");

const JOURNAL_PATH = path.join(__dirname, "..", "journal.json");

function saveSignal(data) {
  let file = [];

  if (fs.existsSync(JOURNAL_PATH)) {
    try {
      file = JSON.parse(fs.readFileSync(JOURNAL_PATH));
    } catch (e) {
      file = [];
    }
  }

  file.push({ time: new Date(), ...data });

  // Batasi 500 entri terakhir agar file tidak membengkak
  if (file.length > 500) file = file.slice(file.length - 500);

  fs.writeFileSync(JOURNAL_PATH, JSON.stringify(file, null, 2));
}

module.exports = saveSignal;
