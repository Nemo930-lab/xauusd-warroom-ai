// ======================================
// XAU/USD WAR ROOM AI v22.0
// FIBONACCI ENGINE
// ======================================

function fibonacciAnalysis(candles) {
  const highs = candles.map(x => Number(x.high));
  const lows = candles.map(x => Number(x.low));

  const high = Math.max(...highs);
  const low = Math.min(...lows);
  const range = high - low;

  const fib = {
    swingHigh: high,
    swingLow: low,
    level236: high - range * 0.236,
    level382: high - range * 0.382,
    level500: high - range * 0.5,
    level618: high - range * 0.618,
    level786: high - range * 0.786,
    extension1272: high + range * 0.272,
    extension1618: high + range * 0.618
  };

  const current = candles[candles.length - 1].close;

  if (current <= fib.level618 && current >= fib.level786) {
    fib.zone = "DISCOUNT AREA - BUY ZONE";
  } else if (current >= fib.level236) {
    fib.zone = "PREMIUM AREA - SELL ZONE";
  } else {
    fib.zone = "MID RANGE";
  }

  return fib;
}

module.exports = fibonacciAnalysis;
