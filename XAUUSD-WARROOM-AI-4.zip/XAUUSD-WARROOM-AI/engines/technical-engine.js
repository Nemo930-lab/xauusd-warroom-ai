// ======================================
// XAU/USD WAR ROOM AI v22.0
// TECHNICAL ENGINE - EMA RSI MACD ATR
// ======================================

const { EMA, RSI, MACD, ATR } = require("technicalindicators");

function technicalAnalysis(candles) {
  const close = candles.map(x => Number(x.close));
  const high = candles.map(x => Number(x.high));
  const low = candles.map(x => Number(x.low));

  const ema20 = EMA.calculate({ period: 20, values: close }).pop();
  const ema50 = EMA.calculate({ period: 50, values: close }).pop();
  const ema200 = EMA.calculate({ period: 200, values: close }).pop();
  const rsi = RSI.calculate({ period: 14, values: close }).pop();

  const macd = MACD.calculate({
    values: close,
    fastPeriod: 12,
    slowPeriod: 26,
    signalPeriod: 9,
    SimpleMAOscillator: false,
    SimpleMASignal: false
  }).pop();

  const atr = ATR.calculate({ period: 14, high, low, close }).pop();

  let score = 0;
  if (ema200 && close.at(-1) > ema200) score += 20; else score -= 20;
  if (ema20 && ema50 && ema20 > ema50) score += 15; else score -= 15;
  if (rsi && rsi > 50) score += 10; else score -= 10;
  if (macd && macd.histogram > 0) score += 15; else score -= 15;

  let signal;
  if (score >= 30) signal = "BUY";
  else if (score <= -30) signal = "SELL";
  else signal = "WAIT";

  return { price: close.at(-1), ema20, ema50, ema200, rsi, macd, atr, score, signal };
}

module.exports = technicalAnalysis;
