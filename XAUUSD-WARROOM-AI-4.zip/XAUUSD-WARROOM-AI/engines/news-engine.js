// ======================================
// XAU/USD WAR ROOM AI v22.0
// NEWS IMPACT ENGINE
// ======================================

function analyzeNews(events = []) {
  let impact = "LOW";
  let warning = "Normal Market";

  const highImpact = [
    "CPI", "NFP", "FOMC", "FED", "INTEREST RATE",
    "POWELL", "NON FARM PAYROLL", "PPI", "GDP"
  ];

  events.forEach(news => {
    highImpact.forEach(keyword => {
      if (news.toUpperCase().includes(keyword)) {
        impact = "HIGH";
        warning = "⚠ HIGH VOLATILITY NEWS";
      }
    });
  });

  const tradingMode = impact === "HIGH" ? "WAIT OR REDUCE LOT" : "NORMAL EXECUTION";

  return { impact, warning, tradingMode };
}

module.exports = analyzeNews;
