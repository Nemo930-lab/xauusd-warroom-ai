// ======================================
// XAU/USD WAR ROOM AI v21.0+
// CANDLE PATTERN ENGINE
// ======================================

function candleAnalysis(candles) {
  const c1 = candles[candles.length - 2];
  const c2 = candles[candles.length - 1];
  const result = { pattern: "NONE", bias: "NEUTRAL", score: 0 };

  // ENGULFING BULLISH
  if (c2.close > c2.open && c1.close < c1.open && c2.close > c1.open) {
    result.pattern = "BULLISH ENGULFING";
    result.bias = "BUY";
    result.score += 20;
  }

  // ENGULFING BEARISH
  if (c2.close < c2.open && c1.close > c1.open && c2.close < c1.open) {
    result.pattern = "BEARISH ENGULFING";
    result.bias = "SELL";
    result.score -= 20;
  }

  const body = Math.abs(c2.close - c2.open);

  // HAMMER
  const wick = Math.min(c2.open, c2.close) - c2.low;
  if (wick > body * 2) {
    result.pattern = "HAMMER";
    result.bias = "BUY";
    result.score += 10;
  }

  // SHOOTING STAR
  const upper = c2.high - Math.max(c2.open, c2.close);
  if (upper > body * 2) {
    result.pattern = "SHOOTING STAR";
    result.bias = "SELL";
    result.score -= 10;
  }

  return result;
}

module.exports = candleAnalysis;
