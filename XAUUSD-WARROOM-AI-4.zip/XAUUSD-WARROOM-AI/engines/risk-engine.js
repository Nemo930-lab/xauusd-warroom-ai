// ======================================
// XAU/USD WAR ROOM AI v22.0
// RISK MANAGEMENT ENGINE
// ======================================

function calculateRisk(balance, riskPercent, entry, stopLoss, takeProfit) {
  const riskMoney = balance * (riskPercent / 100);
  const distance = Math.abs(entry - stopLoss);
  const reward = Math.abs(takeProfit - entry);
  const rr = distance ? reward / distance : 0;

  // Estimasi lot sederhana, sesuaikan dengan broker
  const lot = distance ? riskMoney / (distance * 100) : 0;

  return {
    balance,
    riskMoney: Number(riskMoney.toFixed(2)),
    distance: Number(distance.toFixed(2)),
    reward: Number(reward.toFixed(2)),
    riskReward: "1 : " + rr.toFixed(2),
    estimatedLot: Number(lot.toFixed(2))
  };
}

module.exports = calculateRisk;
