// ======================================
// XAU/USD WAR ROOM AI v22.0
// SNIPER ENTRY ENGINE
// ======================================

function sniperEntry(price, smartMoney, fibonacci, bias) {
  const setup = {
    type: "NO TRADE",
    entry: null,
    sl: null,
    tp1: null,
    tp2: null,
    confidence: 0
  };

  // BUY SETUP
  if (bias.includes("BULL") && smartMoney.bias === "INSTITUTIONAL BUY") {
    setup.type = "BUY LIMIT";
    setup.entry = Number(fibonacci.level618.toFixed(2));
    setup.sl = Number((fibonacci.swingLow - 5).toFixed(2));
    setup.tp1 = Number(fibonacci.swingHigh.toFixed(2));
    setup.tp2 = Number(
      (fibonacci.swingHigh + (fibonacci.swingHigh - fibonacci.swingLow) * 0.618).toFixed(2)
    );
    setup.confidence = 85;
  }

  // SELL SETUP
  else if (bias.includes("BEAR") && smartMoney.bias === "INSTITUTIONAL SELL") {
    setup.type = "SELL LIMIT";
    setup.entry = Number(fibonacci.level618.toFixed(2));
    setup.sl = Number((fibonacci.swingHigh + 5).toFixed(2));
    setup.tp1 = Number(fibonacci.swingLow.toFixed(2));
    setup.tp2 = Number(
      (fibonacci.swingLow - (fibonacci.swingHigh - fibonacci.swingLow) * 0.618).toFixed(2)
    );
    setup.confidence = 85;
  }

  return setup;
}

module.exports = sniperEntry;
