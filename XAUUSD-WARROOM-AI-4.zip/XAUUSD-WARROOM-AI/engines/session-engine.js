// ======================================
// XAU/USD WAR ROOM AI v22.0
// SESSION ENGINE (jam berdasarkan WIB)
// ======================================

function sessionAnalysis(hour) {
  let session, behavior, volatility;

  if (hour >= 7 && hour < 15) {
    session = "ASIA";
    behavior = "Range / Liquidity Build";
    volatility = "LOW - MEDIUM";
  } else if (hour >= 15 && hour < 21) {
    session = "LONDON";
    behavior = "Breakout / Trend Expansion";
    volatility = "HIGH";
  } else {
    session = "NEW YORK";
    behavior = "Volatility + Reversal";
    volatility = "VERY HIGH";
  }

  return { session, behavior, volatility };
}

module.exports = sessionAnalysis;
