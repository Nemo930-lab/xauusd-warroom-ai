// ======================================
// CONFIDENCE AI ENGINE
// ======================================

function confidenceScore(data) {
  let score = 50;

  score += data.technical.score;
  score += data.smart.score;
  score += data.candle.score;

  if (data.news === "HIGH") score -= 20;

  if (score > 100) score = 100;
  if (score < 0) score = 0;

  let grade;
  if (score >= 85) grade = "A+ SNIPER";
  else if (score >= 70) grade = "A SETUP";
  else if (score >= 55) grade = "B SETUP";
  else grade = "NO TRADE";

  return { score, grade };
}

module.exports = confidenceScore;
