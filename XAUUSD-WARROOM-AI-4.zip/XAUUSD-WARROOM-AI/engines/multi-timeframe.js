// ======================================
// XAU/USD WAR ROOM AI v22.0
// MULTI TIMEFRAME ENGINE
// ======================================

function analyzeTF(data) {
  let score = 0;

  if (data.price > data.ema200) score += 20; else score -= 20;
  if (data.rsi > 50) score += 10; else score -= 10;
  if (data.macd && data.macd.histogram > 0) score += 10; else score -= 10;

  let direction;
  if (score >= 20) direction = "BULLISH";
  else if (score <= -20) direction = "BEARISH";
  else direction = "NEUTRAL";

  return { score, direction };
}

function multiTimeframeAnalysis(timeframes) {
  let totalScore = 0;
  const result = {};

  for (const tf in timeframes) {
    const analysis = analyzeTF(timeframes[tf]);
    result[tf] = analysis;
    totalScore += analysis.score;
  }

  let bias;
  if (totalScore >= 60) bias = "STRONG BULLISH";
  else if (totalScore <= -60) bias = "STRONG BEARISH";
  else bias = "RANGE / WAIT";

  return { bias, totalScore, detail: result };
}

module.exports = multiTimeframeAnalysis;
