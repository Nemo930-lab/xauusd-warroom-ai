// ==========================================
// XAU/USD WAR ROOM AI v22.0 CONFIG
// ==========================================

require("dotenv").config();

const CONFIG = {

  // Masukkan API Key harga realtime (Twelve Data / Finnhub / Broker API)
  API_KEY: process.env.GOLD_API_KEY || "MASUKKAN_API_KEY_ANDA",

  SYMBOL: "XAU/USD",

  DEFAULT_TIMEFRAME: "5min",

  SERVER_PORT: process.env.PORT || 3000,

  TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || "",
  TELEGRAM_CHAT_ID: process.env.TELEGRAM_CHAT_ID || ""

};

module.exports = CONFIG;
